<?php
define('EARNNOW_APP', true);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

// Auth guard
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$pageTitle = 'Training & Videos';
require_once __DIR__ . '/includes/header.php';

$videos = getVideos(true); // Active videos only

// Determine current selected video
$selectedId = isset($_GET['v']) ? (int)$_GET['v'] : 0;
$activeVideo = null;

if (!empty($videos)) {
    if ($selectedId > 0) {
        foreach ($videos as $v) {
            if ($v['id'] === $selectedId) {
                $activeVideo = $v;
                break;
            }
        }
    }
    if (!$activeVideo) {
        $activeVideo = $videos[0]; // default to first video
    }
}

$parsedSource = $activeVideo ? parseVideoSource($activeVideo['video_url']) : null;
?>

<!-- Page Header -->
<div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 14px; margin-bottom: 20px;">
  <div>
    <h1 style="font-size: 1.75rem; font-weight: 800; color: var(--text-main); margin-bottom: 4px;">Training &amp; Tutorials</h1>
    <p style="color: var(--text-secondary); font-size: 0.9rem;">
      Watch official platform guides, deposit instructions, and investment walkthroughs directly inside the platform.
    </p>
  </div>
  <?php if (($currentUser['role'] ?? '') === 'admin'): ?>
    <a href="admin/videos.php" class="btn btn-secondary" style="font-size: 0.82rem; padding: 7px 14px; display: inline-flex; align-items: center; gap: 6px;">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
      Admin: Manage Videos
    </a>
  <?php endif; ?>
</div>

<?php if (empty($videos) || !$activeVideo): ?>
  <div class="card" style="text-align: center; padding: 60px 20px; color: var(--text-secondary);">
    <div style="width: 64px; height: 64px; border-radius: 50%; background: var(--bg-subtle); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 14px; color: var(--text-muted);">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg>
    </div>
    <h3 style="font-size: 1.2rem; color: var(--text-main); margin-bottom: 6px;">No Videos Available Yet</h3>
    <p style="font-size: 0.88rem; max-width: 400px; margin: 0 auto 16px auto;">The platform administrator will add video tutorials soon. Please check back later.</p>
    <a href="index.php" class="btn btn-pwa" style="font-size: 0.85rem; padding: 8px 18px;">Return to Dashboard</a>
  </div>
<?php else: ?>

  <!-- Video Main Layout (Player + Playlist) -->
  <div style="display: grid; grid-template-columns: 2.2fr 1fr; gap: 24px; align-items: start;">
    
    <!-- Left Column: The Interactive Player & Video Details -->
    <div>
      <div class="card" style="padding: 0; overflow: hidden; background: #000; border: 1px solid var(--border-glass); border-radius: var(--radius-lg); box-shadow: var(--shadow-glass); position: relative;">
        
        <!-- 16:9 Responsive Video Frame -->
        <div style="position: relative; width: 100%; padding-top: 56.25%; background: #0B0E14; overflow: hidden;">
          
          <?php if ($parsedSource['type'] === 'html5'): ?>
            <!-- HTML5 Direct Player with Full Native Controls (Play/Pause, Fullscreen, Volume, Progress Bar) -->
            <video 
              id="mainPlatformVideo" 
              controls 
              playsinline 
              preload="metadata"
              style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: contain; background: #000;"
              poster="<?php echo htmlspecialchars($activeVideo['thumbnail'] ?? ''); ?>">
              <source src="<?php echo htmlspecialchars($parsedSource['src']); ?>" type="video/mp4">
              Your browser does not support the video tag.
            </video>

          <?php elseif ($parsedSource['type'] === 'youtube' || $parsedSource['type'] === 'vimeo' || $parsedSource['type'] === 'embed'): ?>
            <!-- In-Platform Secure Embedded Player (YouTube / Vimeo / Embed with Fullscreen & Controls) -->
            <iframe 
              id="mainPlatformIframe"
              src="<?php echo htmlspecialchars($parsedSource['embed_url']); ?>" 
              title="<?php echo htmlspecialchars($activeVideo['title']); ?>"
              style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: 0;" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
              allowfullscreen>
            </iframe>

          <?php elseif ($parsedSource['type'] === 'raw_embed'): ?>
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
              <?php echo $parsedSource['html']; ?>
            </div>
          <?php endif; ?>

        </div>

      </div>

      <!-- Video Meta Details Box -->
      <div class="card" style="margin-top: 16px;">
        <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 12px;">
          <div>
            <div style="display: inline-flex; align-items: center; gap: 6px; background: rgba(147, 215, 38, 0.12); color: var(--accent-lime); border: 1px solid var(--accent-lime); padding: 2px 8px; border-radius: 12px; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; margin-bottom: 8px;">
              <span style="width: 6px; height: 6px; border-radius: 50%; background: var(--accent-lime);"></span>
              Official Tutorial
            </div>
            <h2 style="font-size: 1.35rem; font-weight: 800; color: var(--text-main); margin-bottom: 4px;">
              <?php echo htmlspecialchars($activeVideo['title']); ?>
            </h2>
            <div style="font-size: 0.78rem; color: var(--text-muted);">
              Published on <?php echo date('M d, Y', strtotime($activeVideo['created_at'])); ?> &bull; In-Platform Playback
            </div>
          </div>

          <!-- Quick Action Buttons -->
          <div style="display: flex; gap: 8px;">
            <button type="button" class="btn btn-secondary" onclick="shareVideoLink()" style="font-size: 0.8rem; padding: 6px 12px; display: inline-flex; align-items: center; gap: 6px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
              Share
            </button>
            <a href="deposit.php" class="btn btn-pwa" style="font-size: 0.8rem; padding: 6px 12px;">
              Start Earning &rarr;
            </a>
          </div>
        </div>

        <?php if (!empty($activeVideo['description'])): ?>
          <div style="font-size: 0.88rem; color: var(--text-secondary); line-height: 1.6; padding-top: 12px; border-top: 1px solid var(--border-glass);">
            <?php echo nl2br(htmlspecialchars($activeVideo['description'])); ?>
          </div>
        <?php endif; ?>
      </div>

    </div>

    <!-- Right Column: Video Playlist / Collection -->
    <div>
      <div class="card" style="padding: 0; overflow: hidden; margin-bottom: 0;">
        <div style="padding: 14px 18px; border-bottom: 1px solid var(--border-glass); background: var(--bg-subtle); display: flex; justify-content: space-between; align-items: center;">
          <h3 style="font-size: 0.95rem; font-weight: 800; color: var(--text-main); margin-bottom: 0;">
            Platform Playlist
          </h3>
          <span style="font-size: 0.72rem; color: var(--text-muted);">
            <?php echo count($videos); ?> Videos
          </span>
        </div>

        <div style="display: flex; flex-direction: column; max-height: 520px; overflow-y: auto;">
          <?php foreach ($videos as $idx => $v): 
            $isSelected = ($v['id'] === $activeVideo['id']);
            $vInfo = parseVideoSource($v['video_url']);
          ?>
            <a href="videos.php?v=<?php echo $v['id']; ?>" style="display: flex; gap: 12px; padding: 14px 16px; border-bottom: 1px solid var(--border-glass); text-decoration: none; transition: background 0.2s ease; background: <?php echo $isSelected ? 'rgba(147, 215, 38, 0.08)' : 'transparent'; ?>; border-left: <?php echo $isSelected ? '3px solid var(--accent-lime)' : '3px solid transparent'; ?>;">
              
              <!-- Video Number / Play Icon -->
              <div style="width: 32px; height: 32px; border-radius: 8px; background: <?php echo $isSelected ? 'var(--accent-lime)' : 'var(--bg-subtle)'; ?>; color: <?php echo $isSelected ? '#000' : 'var(--text-secondary)'; ?>; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 0.78rem; font-weight: 800;">
                <?php if ($isSelected): ?>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                <?php else: ?>
                  <?php echo $idx + 1; ?>
                <?php endif; ?>
              </div>

              <!-- Title & Meta -->
              <div style="flex: 1; min-width: 0;">
                <div style="font-size: 0.85rem; font-weight: 700; color: <?php echo $isSelected ? 'var(--accent-lime)' : 'var(--text-main)'; ?>; margin-bottom: 2px; line-height: 1.3; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
                  <?php echo htmlspecialchars($v['title']); ?>
                </div>
                <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase;">
                  <?php echo htmlspecialchars($vInfo['type']); ?> &bull; Play Inside App
                </div>
              </div>

            </a>
          <?php endforeach; ?>
        </div>

      </div>

      <!-- Quick Platform Info Note -->
      <div class="card" style="margin-top: 16px; font-size: 0.82rem; color: var(--text-secondary); line-height: 1.5;">
        <strong style="color: var(--text-main); display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent-lime)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
          Direct In-Platform Video
        </strong>
        All videos play directly inside the platform without redirecting to external sites. Supports Fullscreen, Volume, and Mobile responsive view.
      </div>
    </div>

  </div>

<?php endif; ?>

<script>
  function shareVideoLink() {
    if (navigator.share) {
      navigator.share({
        title: <?php echo json_encode($activeVideo['title'] ?? 'EarnNow Video'); ?>,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href).then(() => {
        alert('Video link copied to clipboard!');
      });
    }
  }
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
